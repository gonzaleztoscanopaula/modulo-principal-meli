import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class MesaService {
  constructor(private prisma: PrismaService) {}

  async obtenerMesasDisponibles() {
    return this.prisma.mesa.findMany({
      where: { disponible: true },
    });
  }

  async cambiarDisponibilidad(id: number, disponible: boolean) {
    // Verifica si la mesa existe en la base de datos
    const mesa = await this.prisma.mesa.findUnique({
      where: { id },
    });

    if (!mesa) {
      throw new NotFoundException(`La mesa con ID ${id} no existe`);
    }

    // Actualiza la disponibilidad si la mesa existe
    return this.prisma.mesa.update({
      where: { id },
      data: { disponible },
    });
  }
}
